const functions = require('firebase-functions');
const express = require('express');

var firebase = require('firebase');

var config = {
    apiKey: "AIzaSyBHKcK45lWqSzx7ZYXT2QsVhFYRCXa1JSU",
    authDomain: "firstprogramassign-4261.firebaseapp.com",
    databaseURL: "https://firstprogramassign-4261.firebaseio.com",
    projectId: "firstprogramassign-4261",
    storageBucket: "firstprogramassign-4261.appspot.com",
    messagingSenderId: "361595006072"
  };
firebase.initializeApp(config);

var rootRef = firebase.database().ref('/locations');
var allPoints = [];

String.prototype.hashCode = function() {
    var hash = 0;
    if (this.length == 0) {
        return hash;
    }
    for (var i = 0; i < this.length; i++) {
        var char = this.charCodeAt(i);
        hash = ((hash<<5)-hash)+char;
        hash = hash & hash; // Convert to 32bit integer
    }
    return hash;
}

rootRef.on('value', function(snapshot) {
    allPoints = snapshot.val();
});

const app = express();

app.get('/points', (request, response) => {
    response.send(allPoints);
});

app.post('/points', (request, response) => {
    console.log(request.body);
    rootRef.child(request.body.toString().hashCode()).set(request.body);
    response.send('{response: "successfully added point"}');
})

exports.app = functions.https.onRequest(app);
